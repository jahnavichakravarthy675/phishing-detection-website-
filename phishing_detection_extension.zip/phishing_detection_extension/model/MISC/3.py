import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, IsolationForest, StackingClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from lightgbm import LGBMClassifier
from sklearn.preprocessing import LabelEncoder

# 1. Load and Clean Data
file_path = 'D:/Rahul/phishing_detection_extension/model/dataset_phishing.csv'
df = pd.read_csv(file_path)
df.drop_duplicates(inplace=True)
df.fillna(df.median(), inplace=True)

# Selecting important features based on the initial exploration
selected_features = [
    'length_url', 'length_hostname', 'nb_dots', 'nb_hyphens', 'nb_at', 'nb_qm', 
    'nb_and', 'nb_or', 'ip', 'domain_registration_length', 'domain_age', 
    'dns_record', 'google_index', 'page_rank'
]

# Preprocessing the data
X = df[selected_features]
y = df['status']

# Encoding target labels (phishing, legitimate)
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Split the dataset into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.3, random_state=42)


# 5. Handle Class Imbalance
smote = SMOTE(random_state=42)
X_train, y_train = smote.fit_resample(X_train, y_train)


# # 6. Train Isolation Forest
# iso_forest = IsolationForest(contamination=0.5, random_state=42)
# iso_forest.fit(X_train)
# anomaly_scores_train = iso_forest.decision_function(X_train)
# anomaly_scores_test = iso_forest.decision_function(X_test)

# # Add anomaly scores as a new feature
# X_train = np.hstack((X_train, anomaly_scores_train.reshape(-1, 1)))
# X_test = np.hstack((X_test, anomaly_scores_test.reshape(-1, 1)))

# 7. Train Random Forest with the new feature
rf_model = RandomForestClassifier(n_estimators=200, class_weight='balanced', random_state=42)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)

# 8. Train Gradient Boosting Classifier
gb_model = GradientBoostingClassifier(n_estimators=100, random_state=42)
gb_model.fit(X_train, y_train)
y_pred_gb = gb_model.predict(X_test)

# 9. Train LightGBM Classifier
lgb_model = LGBMClassifier(n_estimators=100, random_state=42)
lgb_model.fit(X_train, y_train)
y_pred_lgb = lgb_model.predict(X_test)


# 11. Stacking Classifier with LightGBM
estimators = [
    ('rf', rf_model),
    ('gb', gb_model),
    ('lgb', lgb_model)
]

stacking_model = StackingClassifier(
    estimators=estimators,
    final_estimator=LogisticRegression(),
    cv=5
)

stacking_model.fit(X_train, y_train)
y_pred_stacking = stacking_model.predict(X_test)


# 12. Soft Voting Classifier
voting_clf_soft = VotingClassifier(
    estimators=[
        ('rf', rf_model),
        ('gb', gb_model),
        ('lgb', lgb_model)
    ],
    voting='soft'  # Soft voting takes average of predicted probabilities
)

# Fit Soft Voting Classifier
voting_clf_soft.fit(X_train, y_train)
y_pred_voting_soft = voting_clf_soft.predict(X_test)

 #13. Hard Voting Classifier
voting_clf_hard = VotingClassifier(
    estimators=[
        ('rf', rf_model),
        ('gb', gb_model),
        ('lgb', lgb_model)
    ],
    voting='hard'  # Hard voting uses majority vote from all models
)

# Fit Hard Voting Classifier
voting_clf_hard.fit(X_train, y_train)
y_pred_voting_hard = voting_clf_hard.predict(X_test)

# 14. Evaluate Models
print("Random Forest Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_rf) * 100))
print("\nRandom Forest Classification Report:\n", classification_report(y_test, y_pred_rf))

print("Gradient Boosting Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_gb) * 100))
print("\nGradient Boosting Classification Report:\n", classification_report(y_test, y_pred_gb))

print("LightGBM Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_lgb) * 100))
print("\nLightGBM Classification Report:\n", classification_report(y_test, y_pred_lgb))

print("Stacking Classifier Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_stacking) * 100))
print("\nStacking Classifier Classification Report:\n", classification_report(y_test, y_pred_stacking))

print("Soft Voting Classifier Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_voting_soft) * 100))
print("\nSoft Voting Classifier Classification Report:\n", classification_report(y_test, y_pred_voting_soft))

print("Hard Voting Classifier Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_voting_hard) * 100))
print("\nHard Voting Classifier Classification Report:\n", classification_report(y_test, y_pred_voting_hard))

# 15. ROC-AUC for Stacking and Voting Models
y_prob_stacking = stacking_model.predict_proba(X_test)[:, 1]
auc_stacking = roc_auc_score(y_test, y_prob_stacking)
print(f"Stacking Classifier ROC-AUC: {auc_stacking:.5f}")



import re
import socket
from urllib.parse import urlparse
import whois
from datetime import datetime

def extract_features(url):
    features = {}
    
    # Parse URL
    parsed_url = urlparse(url)
    hostname = parsed_url.hostname or ''
    
    # Feature 1: Length of URL
    features['length_url'] = len(url)
    
    # Feature 2: Length of Hostname
    features['length_hostname'] = len(hostname)
    
    # Feature 3: Number of Dots in URL
    features['nb_dots'] = url.count('.')
    
    # Feature 4: Number of Hyphens in URL
    features['nb_hyphens'] = url.count('-')
    
    # Feature 5: Number of '@' in URL
    features['nb_at'] = url.count('@')
    
    # Feature 6: Number of Question Marks in URL
    features['nb_qm'] = url.count('?')
    
    # Feature 7: Number of 'and' in URL
    features['nb_and'] = url.lower().count('and')
    
    # Feature 8: Number of 'or' in URL
    features['nb_or'] = url.lower().count('or')
    
    # Feature 9: Does URL contain IP address (1 if yes, 0 if no)
    try:
        socket.inet_aton(hostname)
        features['ip'] = 1
    except socket.error:
        features['ip'] = 0
    
    # Feature 10: Domain Registration Length (days between registration and expiry)
    try:
        domain_info = whois.whois(hostname)
        creation_date = domain_info.creation_date
        expiration_date = domain_info.expiration_date
        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        if isinstance(expiration_date, list):
            expiration_date = expiration_date[0]
        
        if creation_date and expiration_date:
            features['domain_registration_length'] = (expiration_date - creation_date).days
        else:
            features['domain_registration_length'] = -1
    except:
        features['domain_registration_length'] = -1
    
    # Feature 11: Domain Age (days since domain was created)
    try:
        if creation_date:
            features['domain_age'] = (datetime.now() - creation_date).days
        else:
            features['domain_age'] = -1
    except:
        features['domain_age'] = -1
    
    # Feature 12: DNS Record (1 if exists, 0 if not)
    try:
        socket.gethostbyname(hostname)
        features['dns_record'] = 1
    except socket.error:
        features['dns_record'] = 0
    
    # Feature 13: Google Index (placeholder, can use search API to check if indexed)
    # For now, set a random value for demo purposes
    features['google_index'] = is_url_indexed(url)  # Placeholder, use Google API to get the real value
    
    # Feature 14: Page Rank (placeholder, can integrate PageRank APIs)
    features['page_rank'] =  get_openpagerank(get_domain_from_url(url), api_key) # Placeholder for PageRank integration

    return features




### GOOGLE INDEX
from googlesearch import search

def is_url_indexed(url):
    try:
        results = list(search(f"site:{url}", num_results=1))
        return 1 if results else 0
    except Exception as e:
        return 0

# url = "http://maillacessonlinee.com/trhnt/uukyy/"
# print(f"URL: {url}, Indexed: {is_url_indexed(url)}")


from urllib.parse import urlparse

def get_domain_from_url(url):
    """
    Extract the domain name from a URL.
    
    :param url: The full URL (e.g., 'https://www.youtube.com/').
    :return: The domain name (e.g., 'youtube.com').
    """
    try:
        parsed_url = urlparse(url)
        # Remove 'www.' if present and return the netloc (domain)
        domain = parsed_url.netloc.replace('www.', '')
        return domain
    except Exception as e:
        return None
    
    
### GET PAGERANK  
import requests
api_key = "ws8g4gkoc04ok0k80co8swog4k8g0cs0okw48804"
def get_openpagerank(domain, api_key):
    """
    Fetch PageRank data for a domain using Open PageRank API.
    
    :param domain: The domain to check (e.g., "example.com").
    :param api_key: Your Open PageRank API key.
    :return: PageRank data or None if an error occurs.
    """
    url = "https://openpagerank.com/api/v1.0/getPageRank"
    headers = {"API-OPR": api_key}
    params = {"domains[]": domain}

    try:
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            data = response.json()
            if data["status_code"] == 200 and "response" in data:
                for item in data["response"]:
                    if item["domain"] == domain and "page_rank_integer" in item:
                        return item["page_rank_integer"]
    except Exception as e:
        return 0


# import pickle
# # Assuming stacking_model is your trained model
# with open("a1.pickle", "wb") as model_file:
#     pickle.dump(iso_forest, model_file, protocol=pickle.HIGHEST_PROTOCOL)
import pickle
# Assuming stacking_model is your trained model
with open("b2.pickle", "wb") as model_file:
    pickle.dump(stacking_model, model_file, protocol=pickle.HIGHEST_PROTOCOL)