import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, IsolationForest, StackingClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
import lightgbm as lgb

# 1. Load and Clean Data
file_path = 'D:/Rahul/phishing_detection_extension/model/cleaned_dataset.csv'
dataset = pd.read_csv(file_path)
dataset.drop_duplicates(inplace=True)
dataset.fillna(dataset.median(), inplace=True)

# 2. Prepare Features and Target Variable
X = dataset.drop(columns=['index', 'Result'])
y = dataset['Result']
X = pd.get_dummies(X, drop_first=True)

# 3. Feature Scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 4. Split Data
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, stratify=y)

# 5. Handle Class Imbalance
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_train, y_train)

# 6. Train Isolation Forest
iso_forest = IsolationForest(contamination='auto', random_state=42)
iso_forest.fit(X_resampled)
anomaly_scores_train = iso_forest.decision_function(X_resampled)
anomaly_scores_test = iso_forest.decision_function(X_test)

# Add anomaly scores as a new feature
X_resampled = np.hstack((X_resampled, anomaly_scores_train.reshape(-1, 1)))
X_test = np.hstack((X_test, anomaly_scores_test.reshape(-1, 1)))

# 7. Train Random Forest with the new feature
rf_model = RandomForestClassifier(n_estimators=200, class_weight='balanced', random_state=42)
rf_model.fit(X_resampled, y_resampled)
y_pred_rf = rf_model.predict(X_test)

# 8. Train Gradient Boosting Classifier
gb_model = GradientBoostingClassifier(n_estimators=100, random_state=42)
gb_model.fit(X_resampled, y_resampled)
y_pred_gb = gb_model.predict(X_test)

# 9. Train LightGBM Classifier
lgb_model = lgb.LGBMClassifier(n_estimators=100, random_state=42)
lgb_model.fit(X_resampled, y_resampled)
y_pred_lgb = lgb_model.predict(X_test)


# 11. Stacking Classifier with LightGBM
estimators = [
    ('rf', rf_model),
    ('gb', gb_model),
    ('lgb', lgb_model)
]

stacking_model = StackingClassifier(
    estimators=estimators,
    final_estimator=LogisticRegression(),
    cv=5
)

stacking_model.fit(X_resampled, y_resampled)
y_pred_stacking = stacking_model.predict(X_test)

# 12. Soft Voting Classifier
voting_clf_soft = VotingClassifier(
    estimators=[
        ('rf', rf_model),
        ('gb', gb_model),
        ('lgb', lgb_model)
    ],
    voting='soft'  # Soft voting takes average of predicted probabilities
)

# Fit Soft Voting Classifier
voting_clf_soft.fit(X_resampled, y_resampled)
y_pred_voting_soft = voting_clf_soft.predict(X_test)

 #13. Hard Voting Classifier
voting_clf_hard = VotingClassifier(
    estimators=[
        ('rf', rf_model),
        ('gb', gb_model),
        ('lgb', lgb_model)
    ],
    voting='hard'  # Hard voting uses majority vote from all models
)

# Fit Hard Voting Classifier
voting_clf_hard.fit(X_resampled, y_resampled)
y_pred_voting_hard = voting_clf_hard.predict(X_test)

# 14. Evaluate Models
print("Random Forest Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_rf) * 100))
print("\nRandom Forest Classification Report:\n", classification_report(y_test, y_pred_rf))

print("Gradient Boosting Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_gb) * 100))
print("\nGradient Boosting Classification Report:\n", classification_report(y_test, y_pred_gb))

print("LightGBM Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_lgb) * 100))
print("\nLightGBM Classification Report:\n", classification_report(y_test, y_pred_lgb))

print("Stacking Classifier Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_stacking) * 100))
print("\nStacking Classifier Classification Report:\n", classification_report(y_test, y_pred_stacking))

print("Soft Voting Classifier Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_voting_soft) * 100))
print("\nSoft Voting Classifier Classification Report:\n", classification_report(y_test, y_pred_voting_soft))

print("Hard Voting Classifier Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred_voting_hard) * 100))
print("\nHard Voting Classifier Classification Report:\n", classification_report(y_test, y_pred_voting_hard))

# 15. ROC-AUC for Stacking and Voting Models
y_prob_stacking = stacking_model.predict_proba(X_test)[:, 1]
auc_stacking = roc_auc_score(y_test, y_prob_stacking)
print(f"Stacking Classifier ROC-AUC: {auc_stacking:.5f}")

y_prob_voting_soft = voting_clf_soft.predict_proba(X_test)[:, 1]
auc_voting_soft = roc_auc_score(y_test, y_prob_voting_soft)
print(f"Soft Voting Classifier ROC-AUC: {auc_voting_soft:.5f}")

import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score

# # 1. Define function to plot individual ROC curve for each model
# def plot_individual_roc_curve(y_test, y_probs, model_name):
#     fpr, tpr, _ = roc_curve(y_test, y_probs)
#     plt.figure(figsize=(8, 6))
#     plt.plot(fpr, tpr, label=f'{model_name} (AUC: {roc_auc_score(y_test, y_probs):.5f})')
#     plt.plot([0, 1], [0, 1], 'k--')  # Diagonal line for random guess 
#     plt.xlim([0.0, 1.0])
#     plt.ylim([0.0, 1.05])
#     plt.title(f'ROC Curve for {model_name}')
#     plt.xlabel('False Positive Rate')
#     plt.ylabel('True Positive Rate')
#     plt.legend(loc='lower right')
#     plt.show()

# # 2. Plot Random Forest ROC Curve
# y_prob_rf = rf_model.predict_proba(X_test)[:, 1]
# plot_individual_roc_curve(y_test, y_prob_rf, "Random Forest")

# # 3. Plot Gradient Boosting ROC Curve
# y_prob_gb = gb_model.predict_proba(X_test)[:, 1]
# plot_individual_roc_curve(y_test, y_prob_gb, "Gradient Boosting")

# # 4. Plot LightGBM ROC Curve
# y_prob_lgb = lgb_model.predict_proba(X_test)[:, 1]
# plot_individual_roc_curve(y_test, y_prob_lgb, "LightGBM")

# # 5. Plot Stacking Classifier ROC Curve
# y_prob_stacking = stacking_model.predict_proba(X_test)[:, 1]
# plot_individual_roc_curve(y_test, y_prob_stacking, "Stacking Classifier")

# # 6. Plot Soft Voting Classifier ROC Curve
# y_prob_voting_soft = voting_clf_soft.predict_proba(X_test)[:, 1]
# plot_individual_roc_curve(y_test, y_prob_voting_soft, "Soft Voting Classifier")

# # 7. For Hard Voting, ROC isn't applicable as it doesn't output probabilities


num_features = dataset.shape[1]
num_features, dataset.columns.tolist() 
print(num_features)


import re
from urllib.parse import urlparse

def extract_url_features(url):
    features = {}

    # Feature extraction logic
    features["having_IP_Address"] = -1 if re.match(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', url) else 1
    features["URL_Length"] = -1 if len(url) > 75 else (0 if len(url) > 54 else 1)
    features["Shortening_Service"] = -1 if re.search(r'(bit\.ly|tinyurl\.com|goo\.gl)', url) else 1
    features["having_At_Symbol"] = -1 if "@" in url else 1
    features["double_slash_redirecting"] = -1 if url.rfind('//') > 7 else 1
    features["Prefix_Suffix"] = -1 if "-" in urlparse(url).netloc else 1
    features["having_Sub_Domain"] = -1 if url.count('.') > 2 else (0 if url.count('.') == 2 else 1)
    features["SSLfinal_State"] = 0  # Placeholder, requires external validation
    features["Domain_registeration_length"] = 0  # Placeholder, requires WHOIS lookup
    features["Favicon"] = 1  # Placeholder, would require HTML parsing
    features["port"] = -1 if re.search(r':[0-9]+', urlparse(url).netloc) else 1
    features["HTTPS_token"] = -1 if "https-" in urlparse(url).netloc else 1
    features["Request_URL"] = 0  # Placeholder, HTML parsing needed
    features["URL_of_Anchor"] = 0  # Placeholder, HTML parsing needed
    features["Links_in_tags"] = 0  # Placeholder, HTML parsing needed
    features["SFH"] = 0  # Placeholder, HTML parsing needed
    features["Submitting_to_email"] = -1 if re.search(r"mailto:", url) else 1
    features["Abnormal_URL"] = 0  # Placeholder, requires domain-owner mapping
    features["Redirect"] = -1 if url.count('//') > 3 else 1
    features["on_mouseover"] = 1  # Placeholder, HTML behavior needed
    features["RightClick"] = 1  # Placeholder, HTML behavior needed
    features["popUpWidnow"] = 1  # Placeholder, HTML behavior needed
    features["Iframe"] = 1  # Placeholder, HTML parsing needed
    features["age_of_domain"] = 0  # Placeholder, requires WHOIS lookup
    features["DNSRecord"] = 0  # Placeholder, requires DNS lookup
    features["web_traffic"] = 0  # Placeholder, requires web traffic API
    features["Page_Rank"] = 0  # Placeholder, requires page rank API
    features["Google_Index"] = 1  # Placeholder, requires Google search API
    features["Links_pointing_to_page"] = 0  # Placeholder, requires link parsing
    features["Statistical_report"] = 0  # Placeholder, requires statistical analysis
    
    return features


import ssl
import socket

def check_ssl(url):
    try:
        parsed_url = urlparse(url)
        hostname = parsed_url.netloc.split(':')[0]
        context = ssl.create_default_context()
        with socket.create_connection((hostname, 443), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                certificate = ssock.getpeercert()
                # If SSL is valid, return 1; else -1
                return 1 if certificate else -1
    except Exception:
        return -1


import whois

def domain_registration_length(url):
    try:
        domain = whois.whois(urlparse(url).netloc)
        creation_date = domain.creation_date
        expiration_date = domain.expiration_date
        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        if isinstance(expiration_date, list):
            expiration_date = expiration_date[0]
        # Calculate domain age in years
        age = (expiration_date - creation_date).days / 365 if creation_date and expiration_date else 0
        return 1 if age > 1 else -1
    except Exception:
        return -1


import requests

def get_web_traffic(url):
    try:
        # Replace with actual traffic API endpoint
        response = requests.get(f"https://api.alexa.com/{url}")
        traffic_data = response.json()
        rank = traffic_data.get('rank', -1)
        return 1 if rank and rank < 100000 else -1
    except Exception:
        return -1


# from googlesearch import search

# def is_google_indexed(url):
#     try:
#         results = list(search(url, num_results=1))
#         return 1 if results else -1
#     except Exception:
#         return -1
