import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, IsolationForest, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
import matplotlib.pyplot as plt
import seaborn as sns
from xgboost import XGBClassifier

# 1. Load and Clean Data
file_path = 'D:/Rahul/phishing_detection_extension/model/dataset.csv'
dataset = pd.read_csv(file_path)
dataset.drop_duplicates(inplace=True)
dataset.fillna(dataset.median(), inplace=True)
# 2. Check for unexpected values or anomalies
# (if necessary, we can explore or clean further)

# 3. Feature Engineering
# Assuming 'having_Sub_Domain' indicates the number of subdomains
#dataset['url_length_per_subdomain'] = dataset['URLURL_Length'] / (dataset['having_Sub_Domain'] + 1)

# 4. Prepare Features and Target Variable
X = dataset.drop(columns=['index', 'Result'])
y = dataset['Result']
X = pd.get_dummies(X, drop_first=True)
# 5. Feature Scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 6. Split Data
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, stratify=y)

# 7. Handle Class Imbalance
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_train, y_train)

# 8. Train Isolation Forest
iso_forest = IsolationForest(contamination='auto', random_state=42)
iso_forest.fit(X_resampled)
anomaly_scores_train = iso_forest.decision_function(X_resampled)
anomaly_scores_test = iso_forest.decision_function(X_test)

# Add anomaly scores as a new feature
X_resampled = np.hstack((X_resampled, anomaly_scores_train.reshape(-1, 1)))
X_test = np.hstack((X_test, anomaly_scores_test.reshape(-1, 1)))

# 9. Train Random Forest with the new feature
rf_model = RandomForestClassifier(n_estimators=200, class_weight='balanced', random_state=42)
rf_model.fit(X_resampled, y_resampled)
y_pred_rf = rf_model.predict(X_test)

# 10. Train Gradient Boosting Classifier
gb_model = GradientBoostingClassifier(n_estimators=100, random_state=42)
gb_model.fit(X_resampled, y_resampled)
y_pred_gb = gb_model.predict(X_test)

# 11. Train XGBoost Classifier
#xgb_model = XGBClassifier(n_estimators=100, use_label_encoder=False, eval_metric='logloss', random_state=42)
#xgb_model.fit(X_resampled, y_resampled)
#y_pred_xgb = xgb_model.predict(X_test)

# 12. Stacking Classifier
estimators = [
    ('rf', rf_model),
    ('gb', gb_model)
    #('xgb', xgb_model)
]

stacking_model = StackingClassifier(
    estimators=estimators,
    final_estimator=LogisticRegression(),
    cv=5
)

stacking_model.fit(X_resampled, y_resampled)
y_pred_stacking = stacking_model.predict(X_test)

# 13. Evaluate Models
print("Random Forest Accuracy:", accuracy_score(y_test, y_pred_rf))
print("\nRandom Forest Classification Report:\n", classification_report(y_test, y_pred_rf))

print("Gradient Boosting Accuracy:", accuracy_score(y_test, y_pred_gb))
print("\nGradient Boosting Classification Report:\n", classification_report(y_test, y_pred_gb))

#print("XGBoost Accuracy:", accuracy_score(y_test, y_pred_xgb))
#print("\nXGBoost Classification Report:\n", classification_report(y_test, y_pred_xgb))

print("Stacking Classifier Accuracy:", accuracy_score(y_test, y_pred_stacking))
print("\nStacking Classifier Classification Report:\n", classification_report(y_test, y_pred_stacking))

# 14. ROC-AUC for Stacking Model
y_prob_stacking = stacking_model.predict_proba(X_test)[:, 1]
auc_stacking = roc_auc_score(y_test, y_prob_stacking)
print(f"Stacking Classifier ROC-AUC: {auc_stacking:.5f}")
