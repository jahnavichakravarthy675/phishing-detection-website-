import pickle
import numpy as np
import pandas as pd
from urllib.parse import urlparse
import socket
import whois
from datetime import datetime
from sklearn.preprocessing import StandardScaler
from googlesearch import search
import requests  # Ensure requests is imported
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, IsolationForest, StackingClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from lightgbm import LGBMClassifier
from sklearn.preprocessing import LabelEncoder

# Load Models
with open("a3.pickle", "rb") as iso_forest_file:
    iso_forest = pickle.load(iso_forest_file)

with open("b3.pickle", "rb") as stacking_model_file:
    stacking_model = pickle.load(stacking_model_file)

api_key = "ws8g4gkoc04ok0k80co8swog4k8g0cs0okw48804"

def is_url_indexed(url):
    try:
        results = list(search(f"site:{url}", num_results=1))
        return 1 if results else 0
    except Exception as e:
        print(f"Error in Google Index: {e}")
        return 0

def get_domain_from_url(url):
    try:
        parsed_url = urlparse(url)
        domain = parsed_url.netloc.replace('www.', '')
        return domain
    except Exception as e:
        print(f"Error extracting domain: {e}")
        return None

def get_openpagerank(domain, api_key):
    url = "https://openpagerank.com/api/v1.0/getPageRank"
    headers = {"API-OPR": api_key}
    params = {"domains[]": domain}
    try:
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            data = response.json()
            if data["status_code"] == 200 and "response" in data:
                for item in data["response"]:
                    if item["domain"] == domain and "page_rank_integer" in item:
                        return item["page_rank_integer"]
        return 0
    except Exception as e:
        print(f"Error in PageRank API: {e}")
        return 0

def extract_features(url):
    features = {}
    parsed_url = urlparse(url)
    hostname = parsed_url.hostname or ''

    features['length_url'] = len(url)
    features['length_hostname'] = len(hostname)
    features['nb_dots'] = url.count('.')
    features['nb_hyphens'] = url.count('-')
    features['nb_at'] = url.count('@')
    features['nb_qm'] = url.count('?')
    features['nb_and'] = url.lower().count('and')
    features['nb_or'] = url.lower().count('or')

    try:
        socket.inet_aton(hostname)
        features['ip'] = 1
    except socket.error:
        features['ip'] = 0

    try:
        domain_info = whois.whois(hostname)
        creation_date = domain_info.creation_date
        expiration_date = domain_info.expiration_date
        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        if isinstance(expiration_date, list):
            expiration_date = expiration_date[0]
        features['domain_registration_length'] = (expiration_date - creation_date).days if expiration_date and creation_date else -1
        features['domain_age'] = (datetime.now() - creation_date).days if creation_date else -1
    except:
        features['domain_registration_length'] = -1
        features['domain_age'] = -1

    try:
        socket.gethostbyname(hostname)
        features['dns_record'] = 1
    except socket.error:
        features['dns_record'] = 0

    features['google_index'] = is_url_indexed(url)
    features['page_rank'] = get_openpagerank(get_domain_from_url(url), api_key)
    return features




urls = [
    "https://www.samsung.com/",
    "https://www.facebook.com/",
    "http://timesofindia.indiatimes.com/",
	  "http://appleid.apple.com-app.es/",
    "http://maillacessonlinee.com/trhnt/uukyy/",
    "http://beta.kenaidanceta.com/postamok/d39a2/source" ]

for url in urls:
        # Example URL
    # url = input("enter url: ")
    domain = get_domain_from_url(url)
    # Extract features
    url_features = extract_features(url)
    # print("Extracted Features:", url_features)

    # # Convert features dictionary to a DataFrame
    features_df = pd.DataFrame([url_features])  # Convert to a DataFrame with one row

    # Train Isolation Forest (should be trained on a dataset, not a single instance)
    iso_forest = IsolationForest(contamination=0.5, random_state=42)

    # Ensure the Isolation Forest is trained on valid data
    iso_forest.fit(features_df)  # Use resampled training data or another dataset for training

    # Calculate anomaly score for the input URL
    anomaly_score = iso_forest.decision_function(features_df)  # Score the extracted features
    features_df['anomaly_score'] = anomaly_score
    # print("Anomaly Score:", anomaly_score)

    # Prepare the features for prediction
    X_url = features_df.values

    # Predict using the stacking model
    y_pred_url = stacking_model.predict(X_url)
    print(f"Prediction for URL '{url}': {'It is a harmful Website' if y_pred_url[0] == 1 else 'It is a Legitimate website'}")

    













# # Example URL
# url = input("Enter URL: ")
# domain = get_domain_from_url(url)
# # Extract features
# url_features = extract_features(url)
# print("Extracted Features:", url_features)

# # # onvert features dictionary to a DataFrame
# features_df = pd.DataFrame([url_features])  # Convert to a DataFrame with one row

# # Train Isolation Forest (should be trained on a dataset, not a single instance)
# iso_forest = IsolationForest(contamination=0.5, random_state=42)

# # Ensure the Isolation Forest is trained on valid data
# iso_forest.fit(features_df)  # Use resampled training data or another dataset for training

# # Calculate anomaly score for the input URL
# anomaly_score = iso_forest.decision_function(features_df)  # Score the extracted features
# features_df['anomaly_score'] = anomaly_score
# # print("Anomaly Score:", anomaly_score)


# # Prepare the features for prediction
# X_url = features_df.values

# # Predict using the stacking model
# y_pred_url = stacking_model.predict(X_url)
# print(f"Prediction for URL '{url}': {'It is a harmful Website' if y_pred_url[0] == 1 else 'It is a Legitimate website'}")




















# # https://www.draw.io/  ----> H
# # https://www.discord.com/     ----> L
# # https://www.zoom.com/   ----> L
# # https://nptel.ac.in/    ----> H
# # https://www.dell.com/en-in  ---> L
# # https://www.apple.com/  ---> L
# # https://www.netflix.com/   ---> L
# # https://www.samsung.com/   ---> L
# # https://www.facebook.com/   ---> L
# # https://www.kaggle.com/     ---> L
# # http://timesofindia.indiatimes.com/   ---> L
# # https://www.chess.com/  ---> L
# # https://www.whatsapp.com/  ---> L
# # https://www.google.com/   ---> L
# # https://www.geeksforgeeks.org/  ---> L
# # https://www.udemy.com/  ---> L
# # https://www.apollohospitals.com/ ---> L