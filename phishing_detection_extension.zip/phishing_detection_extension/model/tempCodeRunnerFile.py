

# # Example URL
# url = input("Enter URL: ")
# domain = get_domain_from_url(url)
# # Extract features
# url_features = extract_features(url)
# print("Extracted Features:", url_features)

# # # onvert features dictionary to a DataFrame
# features_df = pd.DataFrame([url_features])  # Convert to a DataFrame with one row

# # Train Isolation Forest (should be trained on a dataset, not a single instance)
# iso_forest = IsolationForest(contamination=0.5, random_state=42)

# # Ensure the Isolation Forest is trained on valid data
# iso_forest.fit(features_df)  # Use resampled training data or another dataset for training

# # Calculate anomaly score for the input URL
# anomaly_score = iso_forest.decision_function(features_df)  # Score the extracted features
# features_df['anomaly_score'] = anomaly_score
# # print("Anomaly Score:", anomaly_score)


# # Prepare the features for prediction
# X_url = features_df.values

# # Predict using the stacking model
# y_pred_url = stacking_model.predict(X_url)
# print(f"Prediction for URL '{url}': {'It is a harmful Website' if y_pred_url[0] == 1 else 'It is a Legitimate website'}")